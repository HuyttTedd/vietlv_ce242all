#### Klarna Kp Module Unit Tests
Please note that we do not and will not follow semantic versioning for any code under this package as the code here is mostly intended for internal use. If you are extending our code we strongly suggest you avoid extending our tests and focus on adding your own.
