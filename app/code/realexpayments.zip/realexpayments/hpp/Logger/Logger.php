<?php

namespace RealexPayments\HPP\Logger;

// @codingStandardsIgnoreFile
class Logger extends \MonoLog\Logger
{
}
