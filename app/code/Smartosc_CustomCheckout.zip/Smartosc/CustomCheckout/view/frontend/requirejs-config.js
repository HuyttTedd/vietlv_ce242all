var config = {
    map: {
        '*': {
            'Magento_Checkout/template/sidebar.html': 'Smartosc_CustomCheckout/template/sidebar.html'
        }
    }
};